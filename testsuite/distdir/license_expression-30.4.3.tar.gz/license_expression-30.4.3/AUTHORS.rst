The following organizations or individuals have contributed to this code:

- Ayan Sinha Mahapatra @AyanSinhaMahapatra
- Carmen Bianca Bakker @carmenbianca
- Chin-Yeung Li @chinyeungli
- Dennis Clark @DennisClark
- John Horan @johnmhoran
- Jono Yang @JonoYang
- Max Mehl @mxmehl
- nexB Inc. @nexB
- Pablo Castellazzi @pcastellazzi
- Peter Kolbus @pkolbus
- Philippe Ombredanne @pombredanne
- Sebastian Schuberth @sschuberth
- Steven Esser @majurg
- Thomas Druez @tdruez
- Uwe L. Korn @xhochy
